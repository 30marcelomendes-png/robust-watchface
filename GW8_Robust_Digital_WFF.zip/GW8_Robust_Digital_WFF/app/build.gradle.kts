
plugins {
    id("com.android.application")
}

android {
    namespace = "com.robust.digital"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.robust.digital"
        minSdk = 34
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = true
        }
    }
}
